var game;
var bulletTime = 0;
var SCREEN_W = 700;
var SCREEN_H = 540;
var direction;
var themeSong;
var endSong;
var bootState = {
    preload: function() {
        game.load.image('progressBar', '../Phaser/assets/progressBar.png');
    },
    create: function() {
        game.global.score = 0;
        game.stage.backgroundColor = "#021193";
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.state.start('load');
    }
};
var loadState = {
    preload: function() {
        //loading sprites here
        var loadingText = game.add.text(game.world.centerX, 150, 'Loading....', {
            font: '30px Play',
            fill: '#FFFFFF'
        });
        loadingText.anchor.setTo(.5, .5);
        var progressBar = game.add.sprite(game.world.centerX - 50, 200, 'progressBar');
        progressBar.anchor.setTo(0, .5);
        game.load.setPreloadSprite(progressBar, 1);
        game.load.image('crouch', '../Phaser/assets/jumpButton.png')
        game.load.image('mario', '../Phaser/assets/mario.png');
        game.load.image('wallV', '../Phaser/assets/wallVertical.png');
        game.load.image('wallH', '../Phaser/assets/wallHorizontal.png');
        game.load.image('coin', '../Phaser/assets/uCoin.png');
        game.load.image('pixel', '../Phaser/assets/pixel.png');
        game.load.image('jump','../Phaser/assets/jumpButton.png');
        game.load.image("right","../Phaser/assets/rightButton.png");
        game.load.image("left","../Phaser/assets/leftButton.png");
        game.load.spritesheet('mario', '../Phaser/assets/marioSS.png', 16, 16);
        game.load.spritesheet("enemy", "../Phaser/assets/greenShell.png", 20, 28);
        //game.load.spritesheet("pixel", "../Phaser/assets/sun.png",50,52);
        game.load.image('background', '../Phaser/assets/background.png');
        game.load.audio('jump', ['../Phaser/assets/jump.ogg', 'assets/jump.mp3']);
        game.load.audio('coin', ['../Phaser/assets/coin.ogg', 'assets/coin.mp3']);
        game.load.audio('dead', ['../Phaser/assets/dead.ogg', 'assets/dead.mp3']);
        game.load.audio('theme', 'assets/theme.mp3');
        game.load.audio('end', 'assets/end.mp3');

    },
    create: function() {
        game.state.start('menu');
    }
};
var menuState = {
    create: function() {
        this.background = game.add.image(350,270, 'background');
        this.background.anchor.setTo(.5,.5)
        this.background.scale.setTo(2);
        
        var text;
        if(game.device.desktop) {
            text = 'Press the Up Arrow to Start!';
            
        } else {
            text = 'Touch the Screen to Start!';
           
        }
        console.log(text);
        var startLabel = game.add.text(game.world.centerX, game.world.centerY + 80, text, {
            font: '25px Arial',
            fill: '#FFFFFF'
        });
        startLabel.anchor.setTo(.5, .5);
        if(!localStorage.getItem('bestScore')) {
            localStorage.setItem('bestScore', 0);
        }
        if(game.global.score > localStorage.getItem('bestScore')) {
            localStorage.setItem('bestScore', game.global.score);
        }
        //   game.add.image(0, 0, 'background');
        var nameLabel = game.add.text(game.world.centerX, 0, 'Mario!!!!!!!!!!', {
            font: '50px Play',
            fill: '#FFFFFF'
        });
        nameLabel.anchor.setTo(.5, .5);
        game.add.tween(nameLabel).to({
            x:game.world.centerX,y: 100
        }, 1000,Phaser.Easing.Bounce.Out, true);//.start();
        var scoreText = 'Score: ' + game.global.score + '\nBest Score: ' + localStorage.getItem('bestScore')
        var scoreLabel = game.add.text(game.world.centerX, game.world.centerY, scoreText, {
            font: '25px Play',
            fill: '#FFFFFF'
        });
        scoreLabel.anchor.setTo(.5, .5);
        if(game.device.desktop){
            var upKey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
            upKey.onDown.addOnce(this.startGame, this);
            var dub = game.input.keyboard.addKey(Phaser.Keyboard.A);
            dub.onDown.addOnce(this.startGame, this);
        }
        else{
             game.input.onTap.addOnce(this.startGame, this);
        }
    },
    startGame: function() {
        game.state.start('main');
    },
    update: function() {}
};
var mainState = {
    //   preload: function()
    //   {
    //      //This function will be executed at the very beginning of this state
    //      //That's where we load the game's assets
    //   },
    create: function() {
        
        if(!game.device.desktop) 
            this.addMobileInputs();
        
        
        game.global.score = 0;
        //This function is called after the preload function
        //Here we set up the game, display sprites, etc.
        this.scoreText = game.add.text(30, 30, 'Score: 0', {
            font: '18px Wingdings',
            fill: '#FFFFFF'
        });
        this.sprite = game.add.sprite(250, 170, "mario");
        game.physics.startSystem(Phaser.Physics.ARCADE);
        this.sprite.anchor.setTo(.5, .5);
        this.sprite.scale.setTo(.295,.295);
        this.sprite.animations.add('right', [4, 5, 6, 7], 8, true);
        this.sprite.animations.add('left', [3, 2, 1, 0], 8, true);
        game.physics.arcade.enable(this.sprite);
        this.sprite.body.gravity.y = 500;
        //  this.sprite.width = 100;
        this.cursor = game.input.keyboard.createCursorKeys();
        this.wasd = {
            dub: game.input.keyboard.addKey(Phaser.Keyboard.W),
            down: game.input.keyboard.addKey(Phaser.Keyboard.S),
            left: game.input.keyboard.addKey(Phaser.Keyboard.A),
            right: game.input.keyboard.addKey(Phaser.Keyboard.D),
            space: game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR),
        };
        // this.movePlayer();
        this.createWorld();
        //this.pixel = game.add.sprite(70, 150, 'pixel'); //fire projectile 
        //this.physics.arcade.enable(this.pixel);
       // this.pixel.enableBody = true;
        this.pixel = game.add.group();
        this.pixel.enableBody = true;
        this.pixel.physicsBodyType = Phaser.Physics.ARCADE;
        this.pixel.createMultiple(30, 'pixel');
        this.pixel.setAll('anchor.x', .5);
        this.pixel.setAll('anchor.y', .5);
        this.pixel.setAll('outOfBoundsKill', true);
        this.pixel.setAll('checkWorldBounds', true);
        //this.pixel.animations.add('fire', [0,1,2],3,true);
        
        this.coin = game.add.sprite(60, 140, 'coin');
        
        //       this.coin = game.add.sprite(60,140,'coin');
        //       this.coin = game.add.sprite(60,140,'coin');
        //       this.coin = game.add.sprite(60,140,'coin');
        //       this.coin = game.add.sprite(60,140,'coin');
        //       this.coin = game.add.sprite(60,140,'coin');
        //       this.coin = game.add.sprite(60,140,'coin');
        this.coin.anchor.setTo(.5, .5);
        game.physics.arcade.enable(this.coin);
        this.enemies = game.add.group();
        this.enemies.enableBody = true;
        this.enemies.createMultiple(10, 'enemy');
        game.time.events.loop(2000, this.spawnEnemy, this);
        
        if(!game.device.desktop) this.addMobileInputs();
        //       this.score = 0;
        this.coinSound = game.add.audio('coin');
        this.jumpSound = game.add.audio('jump');
        this.deadSound = game.add.audio('dead');
        this.theme = game.add.audio("theme");
        this.end = game.add.audio("end");
        this.emitter = game.add.emitter(this.sprite.x, this.sprite.y, 15) //creates emitter
        this.emitter.makeParticles('mario')
        this.emitter.setYSpeed(0, -100); //direction of emitter
        this.emitter.setXSpeed(0, -200);
//         this.crouch = game.add.sprite(180, 250, 'crouch');
//         this.crouch.scale.setTo(-1, -1)
        //this.emitter.start(true,500,0,0,0); //begins emitter
        
        //this.theme.play();
    
    },
    update: function() {
        console.log(themeSong);
        
        //console.log(this.moveLeft);
        if(this.sprite.position.y > 540) {
            this.sprite.position.y = 20;
        }
        if(this.sprite.position.y < 0) {
            this.sprite.position.y = 540;
        }
        // this.sprite.angle++;
        game.physics.arcade.collide(this.sprite, this.walls);
        this.movePlayer();
        game.physics.arcade.overlap(this.sprite, this.coin, this.takeCoin, null, this);
        // game.physics.arcade.overlap(this.pixel, this.enemies,)
        game.physics.arcade.collide(this.enemies, this.walls);
        game.physics.arcade.overlap(this.enemies, this.sprite, this.restart, null, this);
        game.physics.arcade.overlap(this.pixel,this.enemies, this.collisionHandler, null, this);
        //This function is called 60 times per second
        //It contains the game's logic
      
        
    },
    collisionHandler: function(bullet, badGuy){
        game.global.score++;
        this.scoreText.text = 'Score: ' + game.global.score;
        bullet.kill();
        badGuy.kill();
        
    },
    movePlayer: function() {
        //if(this.sprite.body.touching.down)
        if(this.cursor.left.isDown || this.wasd.left.isDown || this.moveLeft) {
            this.direction = true;
            this.sprite.body.velocity.x = -200;
            this.sprite.animations.play('left');
        } else if(this.cursor.right.isDown || this.wasd.right.isDown || this.moveRight) {
            this.direction = false;
            this.sprite.body.velocity.x = 200;
            this.sprite.animations.play('right');
        } else {
            this.sprite.body.velocity.x = 0;
            this.sprite.animations.stop();
            this.sprite.frame = 4;
        }
        if(this.sprite.body.touching.down &&this.cursor.up.isDown || this.wasd.dub.isDown && this.sprite.body.touching.down) {
            this.jumpSound.play();
            this.sprite.body.velocity.y = -300;
            
        }
        if(this.wasd.space.isDown){
            
           this.shootPixel();
        }
    },
    shootPixel: function() {
       
            if (game.time.now > bulletTime)
    {
        //  Grab the first bullet we can from the pool
        
        
         bullet = this.pixel.getFirstExists(false);
        bullet.anchor.setTo(.5,.5)
         bullet.scale.setTo(.5);

        if (bullet)
        {  
            
            //  And fire it
            bullet.reset(this.sprite.x, this.sprite.y);
            if(this.direction == true){
                bullet.body.velocity.x = -400;
                bullet.scale.setTo(-.5);
            }
            
            
            else{
                bullet.body.velocity.x = 400;
                bullet.scale.setTo(.5);
            }
                
            
           
            bulletTime = game.time.now + 200;
            
            //bullet.animations.play("fire");
        }
    }
        
    },
    createWorld: function() {
        themeSong = true;
        endSong = false;
        if(themeSong == true)
            {
                this.theme.play();
            }
        else
            {
                this.theme.stop();
            }
        this.walls = game.add.group();
        this.walls.enableBody = true;
        // this.walls.anchor.setTo(.5,.5);
        game.add.sprite(0, 10, 'wallV', 0, this.walls);//leftwall
        game.add.sprite(0,250 , 'wallV', 0, this.walls);//botleftwall
        game.add.sprite(680, 10, 'wallV', 0, this.walls);//rightwall
        game.add.sprite(680, 250, 'wallV', 0, this.walls);//botrightwall
       
        game.add.sprite(0, 0, 'wallH', 0, this.walls);//left ceiling
        game.add.sprite(500, 0, 'wallH', 0, this.walls);//right ceiling 
        game.add.sprite(480, 520, 'wallH', 0, this.walls);//right floor
        game.add.sprite(10, 520, 'wallH', 0, this.walls);//left floor
       
        game.add.sprite(00, 160, 'wallH', 0, this.walls);//2nd
       
        game.add.sprite(00, 320, 'wallH', 0, this.walls);//4th
        
        game.add.sprite(400, 320, 'wallH', 0, this.walls);//

        game.add.sprite(400, 160, 'wallH', 0, this.walls);//
        
       
        game.add.sprite(150, 80, 'wallH', 0, this.walls);//top middle
        game.add.sprite(150, 240, 'wallH', 0, this.walls);//bot middle
        game.add.sprite(550, 80, 'wallH', 0, this.walls);//top middle
       game.add.sprite(550, 240, 'wallH', 0, this.walls);//bot middle
       
        this.walls.setAll('body.immovable', true);
    },
    takeCoin: function() {
        //   this.coin.kill();
        this.moveCoin();
        game.add.tween(this.sprite.scale).to({
            x: .6,
            y: .6
        }, 50).to({
            x: .295,
            y: .295
        }, 150).start();
        game.global.score++;
        this.scoreText.text = 'Score: ' + game.global.score;
        this.coinSound.play();
    },
    moveCoin: function() {
        var coinPosition = [{
            x: 140,
            y: 60
        }, {
            x: 360,
            y: 60
        }, {
            x: 60,
            y: 140
        }, {
            x: 440,
            y: 140
        }, {
            x: 130,
            y: 300
        }, {
            x: 370,
            y: 300
        }];
        for(var i = 0; i < coinPosition.length; i++) {
            if(coinPosition[i].x == this.coin.x) {
                coinPosition.splice(i, 1);
            }
        }
        var newPosition = coinPosition[game.rnd.integerInRange(0, coinPosition.length - 1)];
        this.coin.reset(newPosition.x, newPosition.y);
    },
    restart: function() {
        themeSong = false;
        endSong = true;
        if(!this.sprite.alive) return;
        this.sprite.kill();
        this.deadSound.play();
        game.state.start('menu');
        //this.end.play();
        if(themeSong == true)
            {
                this.theme.play();
            }
        else
            {
                this.theme.stop();
            }
    },
    spawnEnemy: function() {
        var enemy = this.enemies.getFirstDead();
        if(!enemy) {
            return;
        }
        enemy.animations.add('spin', [0, 1, 2], 8, true);
        enemy.anchor.setTo(.5, 1);
        enemy.reset(game.world.centerX, 0);
        enemy.body.gravity.y = 500;
        enemy.body.velocity.x = 100 * Phaser.Math.randomSign();
        enemy.body.bounce.x = 1;
        enemy.checkWorldBounds = true;
        enemy.outOfBoundsKill = true;
        enemy.animations.play('spin');
    },
    addMobileInputs: function() {
        this.moveLeft = false;
        this.moveRight = false;
        
        this.jumpButton = game.add.sprite(350, 247, 'jump');
        this.jumpButton.inputEnabled = true;
        this.jumpButton.alpha = .5;
        
        this.leftButton = game.add.sprite(50, 247, 'left');
        this.leftButton.inputEnabled = true;
        this.leftButton.alpha = .5;
        
        this.rightButton = game.add.sprite(130, 247, 'right');
        this.rightButton.inputEnabled = true;
        this.rightButton.alpha = .5;
        
        this.jumpButton.events.onInputDown.add(this.jumpPlayer, this); //calls jumpPlayer when pushed
       
        this.leftButton.events.onInputOver.add(function() {
            this.moveLeft = true;
            this.leftButton.alpha = 1;
        }, this);
        this.leftButton.events.onInputOut.add(function() {
            this.moveLeft = false;
            this.leftButton.alpha = .5;
        }, this);
        this.leftButton.events.onInputDown.add(function() {
            this.moveLeft = true;
            this.leftButton.alpha = 1;
        }, this);
        this.leftButton.events.onInputUp.add(function() {
            this.moveLeft = false;
            this.leftButton.alpha = .5;
        }, this);
        this.rightButton.events.onInputOver.add(function() {
            this.moveRight = true;
            this.rightButton.alpha = 1;
        }, this);
        this.rightButton.events.onInputOut.add(function() {
            this.moveRight = false;
            this.rightButton.alpha = .5;
        }, this);
        this.rightButton.events.onInputDown.add(function() {
            this.moveRight = true;
            this.rightButton.alpha = 1;
        }, this);
        this.rightButton.events.onInputUp.add(function() {
            this.moveRight = false;
            this.rightButton.alpha = .5;
        }, this);
    },
    jumpPlayer: function() {
        if(this.sprite.body.touching.down) {
            
            this.sprite.body.velocity.y = -320;
            
        }
    }
};
game = new Phaser.Game(SCREEN_W, SCREEN_H, Phaser.AUTO, 'game');
game.state.add('boot', bootState);
game.state.add('load', loadState);
game.state.add('menu', menuState);
game.state.add('main', mainState);
game.global = {
    Score: 0
}
game.state.start('boot');